import { CoupleApp } from '@/components/couple/couple-app'

export default function Page() {
  return <CoupleApp />
}
