'use client'

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react'
import { doc, onSnapshot, setDoc, type DocumentData } from 'firebase/firestore'
import { getToken, onMessage } from 'firebase/messaging'
import { db, COUPLE_DOC_PATH, VAPID_KEY, getMessagingIfSupported } from './firebase'

export type Partner = 'Moe' | 'Rio'
export const PARTNERS: Partner[] = ['Moe', 'Rio']

export type ThemeName = 'paper' | 'night' | 'sea' | 'dusk'

export type MoodEntry = { mood: string; energy: number; note: string }
export type Activity = {
  id: number
  title: string
  assignee: Partner | 'معاً'
  category: string
  completed: boolean
}
export type Message = {
  id: number
  from: Partner
  text: string
  time: string
  hearts: number
}
export type Memory = { id: number; src: string; caption: string; date: string; by: Partner }

export type Settings = {
  theme: ThemeName
  partnerA: string | null
  partnerB: string | null
  fontSize: number
  brightness: number
}

const DEFAULT_SETTINGS: Settings = {
  theme: 'paper',
  partnerA: null,
  partnerB: null,
  fontSize: 16,
  brightness: 100,
}

const SETTINGS_KEY = 'masahatna-settings'
const DATA_KEY = 'masahatna-data'

const MEMORIES: Memory[] = [
  { id: 1, src: '/memories/beach.png', caption: 'أول غروب معاً', date: 'مارس', by: 'Moe' },
  { id: 2, src: '/memories/coffee.png', caption: 'قهوة الصباح', date: 'مايو', by: 'Rio' },
  { id: 3, src: '/memories/kitchen.png', caption: 'طبخة فاشلة لذيذة', date: 'يوليو', by: 'Rio' },
  { id: 4, src: '/memories/desert.png', caption: 'ليلة البر', date: 'سبتمبر', by: 'Moe' },
]

const DEFAULT_MOODS: Record<Partner, MoodEntry> = {
  Moe: { mood: '😊', energy: 72, note: 'يوم عمل هادئ' },
  Rio: { mood: '🤗', energy: 58, note: '' },
}

const DEFAULT_ACTIVITIES: Activity[] = [
  { id: 1, title: 'تحضير عشاء الجمعة', assignee: 'معاً', category: 'الطبخ', completed: false },
  { id: 2, title: 'شراء مستلزمات البيت', assignee: 'Moe', category: 'التسوق', completed: true },
  { id: 3, title: 'مشي مسائي ٣٠ دقيقة', assignee: 'Rio', category: 'الرياضة', completed: false },
]

const DEFAULT_MESSAGES: Message[] = [
  { id: 1, from: 'Moe', text: 'شاكر جداً لكل ما تفعلينه، وجودك يجعل الأيام أخف.', time: '10:30 ص', hearts: 1 },
  { id: 2, from: 'Rio', text: 'وأنا ممتنة لصبرك معي هذا الأسبوع. نحتفل الليلة؟', time: '11:05 ص', hearts: 2 },
]

type LastAction = {
  id: string
  by: Partner
  title: string
  body: string
} | null

type PersistedData = {
  moods: Record<Partner, MoodEntry>
  activities: Activity[]
  messages: Message[]
  tokens?: Partial<Record<Partner, string>>
  lastAction?: LastAction
}

type Store = {
  currentUser: Partner
  setCurrentUser: (p: Partner) => void
  moods: Record<Partner, MoodEntry>
  saveMood: (entry: MoodEntry) => void
  activities: Activity[]
  addActivity: (a: Omit<Activity, 'id' | 'completed'>) => void
  toggleActivity: (id: number) => void
  deleteActivity: (id: number) => void
  messages: Message[]
  sendMessage: (text: string) => void
  heartMessage: (id: number) => void
  memories: Memory[]
  settings: Settings
  updateSettings: (patch: Partial<Settings>) => void
  resetSettings: () => void
  toast: string | null
  notify: (msg: string) => void
  notificationsEnabled: boolean
  notificationsSupported: boolean
  enableNotifications: () => Promise<void>
}

const CoupleContext = createContext<Store | null>(null)

const docRef = doc(db, ...COUPLE_DOC_PATH)

function makeLastAction(by: Partner, title: string, body: string): NonNullable<LastAction> {
  return { id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, by, title, body }
}

export function CoupleProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<Partner>('Moe')
  const [moods, setMoods] = useState<Record<Partner, MoodEntry>>(DEFAULT_MOODS)
  const [activities, setActivities] = useState<Activity[]>(DEFAULT_ACTIVITIES)
  const [messages, setMessages] = useState<Message[]>(DEFAULT_MESSAGES)
  const [tokens, setTokens] = useState<Partial<Record<Partner, string>>>({})
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS)
  const [toast, setToast] = useState<string | null>(null)
  const [notificationsSupported, setNotificationsSupported] = useState(false)
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const loaded = useRef(false)
  // Keep a live copy of the latest state in refs so action creators (memoized once via
  // useCallback below isn't needed here since `value` is rebuilt each render) always
  // read fresh data when computing writes — avoids stale-closure bugs with Firestore.
  const stateRef = useRef({ moods, activities, messages, tokens, currentUser })
  stateRef.current = { moods, activities, messages, tokens, currentUser }

  // 1. Instant paint from the local cache (works offline / before Firestore responds).
  useEffect(() => {
    try {
      const rawSettings = localStorage.getItem(SETTINGS_KEY)
      if (rawSettings) setSettings({ ...DEFAULT_SETTINGS, ...JSON.parse(rawSettings) })
    } catch {}
    try {
      const rawData = localStorage.getItem(DATA_KEY)
      if (rawData) {
        const parsed: Partial<PersistedData> = JSON.parse(rawData)
        if (parsed.moods) setMoods({ ...DEFAULT_MOODS, ...parsed.moods })
        if (parsed.activities) setActivities(parsed.activities)
        if (parsed.messages) setMessages(parsed.messages)
        if (parsed.tokens) setTokens(parsed.tokens)
      }
    } catch {}
    loaded.current = true
  }, [])

  // 2. Real-time sync: whichever partner's device changes something, the other partner's
  // screen updates live through this Firestore document — this is what makes it "shared"
  // across two phones instead of just two tabs on the same browser.
  useEffect(() => {
    const unsubscribe = onSnapshot(
      docRef,
      (snap) => {
        if (snap.exists()) {
          const data = snap.data() as DocumentData
          if (data.moods) setMoods({ ...DEFAULT_MOODS, ...data.moods })
          if (data.activities) setActivities(data.activities)
          if (data.messages) setMessages(data.messages)
          if (data.tokens) setTokens(data.tokens)
        } else {
          // First time ever opening the app on either phone: seed the shared doc.
          setDoc(docRef, {
            moods: stateRef.current.moods,
            activities: stateRef.current.activities,
            messages: stateRef.current.messages,
          }).catch(() => {})
        }
      },
      () => {
        // Offline or blocked by Firestore rules — the app keeps working from local cache.
      },
    )
    return () => unsubscribe()
  }, [])

  // 3. Cache the shared data locally too, so a reload while offline still shows real content.
  useEffect(() => {
    if (!loaded.current) return
    try {
      const data: PersistedData = { moods, activities, messages, tokens }
      localStorage.setItem(DATA_KEY, JSON.stringify(data))
    } catch {}
  }, [moods, activities, messages, tokens])

  useEffect(() => {
    getMessagingIfSupported().then((m) => setNotificationsSupported(!!m))
  }, [])

  // Firebase only shows a notification automatically when the tab/app is in the
  // BACKGROUND (handled by the shared PWA service worker). When it's open and focused,
  // we have to show it ourselves — otherwise a push that arrives while you're
  // looking at the screen produces nothing at all.
  useEffect(() => {
    let unsubscribe: (() => void) | undefined
    getMessagingIfSupported().then((messaging) => {
      if (!messaging) return
      unsubscribe = onMessage(messaging, (payload) => {
        const title = payload.data?.title || payload.notification?.title || 'مساحتنا'
        const body = payload.data?.body || payload.notification?.body || ''
        setToast(body ? `${title}: ${body}` : title)
        if (toastTimer.current) clearTimeout(toastTimer.current)
        toastTimer.current = setTimeout(() => setToast(null), 2600)
        if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
          navigator.serviceWorker.ready
            .then((reg) => reg.showNotification(title, { body, icon: '/icons/icon-192.png', dir: 'rtl' }))
            .catch(() => {})
        }
      })
    })
    return () => unsubscribe?.()
  }, [])

  useEffect(() => {
    const root = document.documentElement
    root.dataset.theme = settings.theme
    root.style.setProperty('--app-font-size', `${settings.fontSize}px`)
    if (settings.partnerA) root.style.setProperty('--partner-a', settings.partnerA)
    else root.style.removeProperty('--partner-a')
    if (settings.partnerB) root.style.setProperty('--partner-b', settings.partnerB)
    else root.style.removeProperty('--partner-b')
    document.body.style.filter = settings.brightness === 100 ? '' : `brightness(${settings.brightness}%)`
    if (loaded.current) localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings))
  }, [settings])

  const notify = useCallback((msg: string) => {
    setToast(msg)
    if (toastTimer.current) clearTimeout(toastTimer.current)
    toastTimer.current = setTimeout(() => setToast(null), 2600)
  }, [])

  const push = useCallback((patch: Partial<PersistedData>) => {
    setDoc(docRef, patch, { merge: true }).catch(() => {
      notify('تعذر مزامنة التغيير — تأكد من الاتصال بالإنترنت')
    })
  }, [notify])

  const enableNotifications = useCallback(async () => {
    const messaging = await getMessagingIfSupported()
    if (!messaging) {
      notify('الإشعارات غير مدعومة على هذا المتصفح')
      return
    }
    try {
      const permission = await Notification.requestPermission()
      if (permission !== 'granted') {
        notify('ما تم السماح بالإشعارات')
        return
      }
      // Use the same service worker as the PWA so there is only one registration/scope.
      const registration = await navigator.serviceWorker.register('/sw.js')
      await navigator.serviceWorker.ready
      const token = await getToken(messaging, { vapidKey: VAPID_KEY, serviceWorkerRegistration: registration })
      if (!token) {
        notify('تعذر تفعيل الإشعارات، حاول مرة ثانية')
        return
      }
      const nextTokens = { ...stateRef.current.tokens, [stateRef.current.currentUser]: token }
      setTokens(nextTokens)
      push({ tokens: nextTokens })
      notify('تم تفعيل الإشعارات على هذا الجهاز')
    } catch {
      notify('صار خطأ أثناء تفعيل الإشعارات')
    }
  }, [notify, push])

  const value = useMemo<Store>(
    () => ({
      currentUser,
      setCurrentUser,
      moods,
      saveMood: (entry) => {
        const next = { ...moods, [currentUser]: entry }
        setMoods(next)
        push({
          moods: next,
          lastAction: makeLastAction(currentUser, 'مزاج جديد', `${currentUser} حدّث مزاجه إلى ${entry.mood}`),
        })
      },
      activities,
      addActivity: (a) => {
        const next = [{ ...a, id: Date.now(), completed: false }, ...activities]
        setActivities(next)
        push({
          activities: next,
          lastAction: makeLastAction(currentUser, 'مهمة جديدة', `${currentUser} أضاف: ${a.title}`),
        })
      },
      toggleActivity: (id) => {
        const target = activities.find((a) => a.id === id)
        const next = activities.map((a) => (a.id === id ? { ...a, completed: !a.completed } : a))
        setActivities(next)
        if (target) {
          const willComplete = !target.completed
          push({
            activities: next,
            lastAction: makeLastAction(
              currentUser,
              'تحديث مهمة',
              `${currentUser} ${willComplete ? 'أنجز' : 'أعاد فتح'}: ${target.title}`,
            ),
          })
        } else {
          push({ activities: next })
        }
      },
      deleteActivity: (id) => {
        const target = activities.find((a) => a.id === id)
        const next = activities.filter((a) => a.id !== id)
        setActivities(next)
        push({
          activities: next,
          ...(target
            ? { lastAction: makeLastAction(currentUser, 'حذف مهمة', `${currentUser} حذف: ${target.title}`) }
            : {}),
        })
      },
      messages,
      sendMessage: (text) => {
        const next = [
          ...messages,
          {
            id: Date.now(),
            from: currentUser,
            text,
            hearts: 0,
            time: new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' }),
          },
        ]
        setMessages(next)
        push({
          messages: next,
          lastAction: makeLastAction(currentUser, `رسالة من ${currentUser}`, text.slice(0, 120)),
        })
      },
      heartMessage: (id) => {
        const next = messages.map((m) => (m.id === id ? { ...m, hearts: m.hearts + 1 } : m))
        setMessages(next)
        const target = messages.find((m) => m.id === id)
        push({
          messages: next,
          ...(target
            ? { lastAction: makeLastAction(currentUser, 'إعجاب برسالة', `${currentUser} أعجب برسالتك`) }
            : {}),
        })
      },
      memories: MEMORIES,
      settings,
      updateSettings: (patch) => setSettings((s) => ({ ...s, ...patch })),
      resetSettings: () => setSettings(DEFAULT_SETTINGS),
      toast,
      notify,
      notificationsEnabled: !!tokens[currentUser],
      notificationsSupported,
      enableNotifications,
    }),
    [currentUser, moods, activities, messages, tokens, settings, toast, notify, notificationsSupported, enableNotifications, push],
  )

  return <CoupleContext.Provider value={value}>{children}</CoupleContext.Provider>
}

export function useCouple() {
  const ctx = useContext(CoupleContext)
  if (!ctx) throw new Error('useCouple must be used within CoupleProvider')
  return ctx
}

export function partnerKey(p: Partner | 'معاً') {
  return p === 'Moe' ? 'a' : p === 'Rio' ? 'b' : 'both'
}

export function energyLabel(energy: number) {
  if (energy < 30) return 'منخفضة'
  if (energy < 70) return 'متوسطة'
  return 'عالية'
}
